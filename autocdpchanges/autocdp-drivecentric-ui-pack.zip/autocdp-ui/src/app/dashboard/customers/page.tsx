"use client";

import { useState, useEffect } from "react";
import { Users } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { LeadsList, type LeadRow } from "@/components/customers/leads-list";
import type { CustomerDetailData } from "@/components/customers/customer-detail-panel";

/**
 * /dashboard/customers
 *
 * This is the refactored customers/leads page that uses the new DriveCentric-
 * style list with a right-side sliding detail panel.
 *
 * Data flow:
 *   1. Page loads — fetch lightweight list rows (`/api/customers/list`).
 *   2. Click a row — `loadDetail(id)` fetches the full `CustomerDetailData`.
 *   3. Detail panel renders as an overlay; closing returns to the list.
 *
 * Wiring TODOs (clearly marked below): swap the stub fetchers for real
 * Supabase queries that respect RLS.
 */
export default function CustomersPage() {
  const [rows, setRows] = useState<LeadRow[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const { rows, total } = await fetchLeadsList();
      if (!cancelled) {
        setRows(rows);
        setTotal(total);
        setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="flex h-full flex-col bg-slate-50">
      <PageHeader
        icon={<Users className="h-5 w-5" />}
        iconBg="bg-emerald-500"
        title="Leads"
        subtitle="Every active lead across the dealership — click any row to open."
      />

      {loading ? (
        <div className="flex flex-1 items-center justify-center text-sm text-slate-500">
          <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-slate-200 border-t-emerald-500" />
          Loading leads…
        </div>
      ) : (
        <LeadsList rows={rows} totalCount={total} loadDetail={loadCustomerDetail} />
      )}
    </div>
  );
}

// ----- Data fetchers --------------------------------------------------------

/**
 * Fetch the list-view rows. Lightweight — only what the table cells display.
 *
 * TODO: Replace with a real Supabase query along the lines of:
 *   const supabase = createBrowserClient();
 *   const { data, count } = await supabase
 *     .from("customers")
 *     .select(`
 *       id, first_name, last_name, lifecycle_stage,
 *       metadata->source as source,
 *       metadata->source_description as source_description,
 *       deal_sales_1:users!sales_1_id(name),
 *       deal_bdc:users!bdc_id(name),
 *       comm_counts:communications(channel)
 *     `, { count: "exact" })
 *     .eq("dealership_id", auth_dealership_id())
 *     .order("created_at", { ascending: false })
 *     .limit(50);
 */
async function fetchLeadsList(): Promise<{ rows: LeadRow[]; total: number }> {
  // STUB — replace with real fetch.
  return {
    total: 770,
    rows: [
      {
        id: "1",
        first_name: "Francisco",
        last_name: "Rodriguez",
        store: "Braman Miami",
        created_label: "9 minutes ago",
        source: "Internet",
        source_description: "Dealer.com - Accelerate DR - Standalone - Credit Application",
        last_attempt_label: "7 months ago",
        next_task: "Overdue",
        next_task_overdue: true,
        first_response: "1m 15s",
        first_user_response: "Waiting",
        deal_sales_1: { name: "Aramis Bringuier", initials: "AB" },
        deal_bdc: { name: "Unknown", initials: "—" },
        text_count: 1,
      },
      {
        id: "2",
        first_name: "Carlos",
        last_name: "Hernandez",
        store: "Braman Miami",
        created_label: "9 minutes ago",
        source: "Campaign",
        source_description: "Automotive Mastermind",
        last_attempt_label: "9 minutes ago",
        next_task: "Overdue",
        next_task_overdue: true,
        first_response: "33s",
        first_user_response: "33s",
        deal_sales_1: { name: "Waleed Radwan", initials: "WR" },
        deal_bdc: { name: "Marsell Brito", initials: "MB" },
        text_count: 1,
        email_count: 1,
      },
      {
        id: "3",
        first_name: "Mark",
        last_name: "Daughters",
        store: "Braman Miami",
        created_label: "22 seconds ago",
        source: "Campaign",
        source_description: "FS Warranty Exp",
        last_attempt_label: "Unknown",
        next_task: "Tomorrow",
        first_response: "Waiting",
        first_user_response: "Waiting",
        deal_sales_1: { name: "Ryan Hernandez", initials: "RH" },
        deal_bdc: { name: "Jonathan Serrano", initials: "JS" },
      },
      // …more rows
    ],
  };
}

/**
 * Fetch full detail for a single customer. Called on row click.
 *
 * TODO: replace with a Supabase query that joins:
 *   - customers
 *   - visits (most recent N)
 *   - communications (most recent N)
 *   - mail_pieces
 *   - any open deal record
 *   - dealership_memories that match the customer's tags
 *
 * Optionally pre-warm a Genius Summary via /api/agents/test if the user has
 * one cached for this customer in dealership_insights.
 */
async function loadCustomerDetail(id: string): Promise<CustomerDetailData | null> {
  // STUB — replace with real fetch keyed off `id`.
  return {
    id,
    first_name: "Mark",
    last_name: "Daughters",
    store: "Braman Miami",
    stage: "Lead",
    customer_number: "3307234",
    phones: [
      { label: "Mobile", value: "(415) 640-4923" },
      { label: "Home", value: "(619) 500-2255" },
    ],
    email: "icasual@gmail.com",
    address: {
      street: "1600 Sw 1st Ave Unit Th-04",
      city: "Miami",
      state: "Fl",
      zip: "33129-1116",
    },
    vehicle_of_interest: "MINI Full Line",
    campaign_source: "FS Warranty Exp",
    best_contact_method: "text",
    best_contact_value: "(619) 500-2255",
    genius_summary: null,
    wish_list: [],
    details: {
      sales_1: { name: "Ryan Hernandez", initials: "RH" },
      bdc: { name: "Jonathan Serrano", initials: "JS" },
    },
    open_deal: {
      status: "Lead",
      status_subtext: "today",
      interested: "0 MINI Full Line",
      trade_in: null,
      source: "Campaign",
      date_created: "May 11, 2026",
    },
    garage: [
      {
        year: 2023,
        make: "MINI",
        model: "Cooper Hardtop",
        owned_since: "November 11, 2022",
      },
    ],
    planned_tasks: [
      {
        id: "pt1",
        type: "task",
        title: "Phone Task",
        timestamp: "Tomorrow at 8:00 AM",
        body: "Day 2 - Lead Status - Touchpoint",
      },
      {
        id: "pt2",
        type: "task",
        title: "Touchpoint",
        timestamp: "Tomorrow at 8:00 AM",
        body: "Day 2 - Lead Status - Touchpoint",
      },
    ],
    past_activity: [
      {
        id: "pa1",
        type: "text",
        title: "Text To Customer",
        author: "Selena Reyes",
        timestamp: "Today at 1:52 PM",
        channel_detail: "(415) 640-4923",
        body: "Good afternoon Mark! This is Selena Reyes from Braman Miami. Is it okay to text you? Reply YES to confirm, or reply STOP at anytime to end. Msg & data rates may apply",
      },
      {
        id: "pa2",
        type: "note",
        title: "Note",
        author: "Selena Reyes",
        timestamp: "Today at 1:51 PM",
        body: "Genius Lead Summary: Hi! My name is Mark Daughters, and I'm interested in learning more about the MINI Full Line, VIN WMW33DH03P2T36060, listed as new at Braman Miami. I came across this through FS Warranty Exp. I would appreciate any additional details you can provide. Thank you!",
      },
      {
        id: "pa3",
        type: "system",
        title: "Deal Imported From System",
        author: "Ryan Hernandez",
        timestamp: "Today at 1:51 PM",
        body: "Preferred Contact Method\n\nHome Email:\nicasual@gmail.com",
      },
    ],
  };
}
