import {
  AppointmentsTable,
  type AppointmentRow,
} from "@/components/appointments/appointments-table";

/**
 * /dashboard/appointments
 *
 * Day-bucketed appointments derived from the `communications` table where
 * channel = 'appointment' (or a future `appointments` table). Status comes
 * from the confirmation webhook + showed_at column.
 *
 * Row click should open the CustomerDetailPanel — wire `onRowClick`.
 */
export default async function AppointmentsPage() {
  const rows = await fetchAppointments();
  return (
    <AppointmentsTable rows={rows} dateLabel="May 11, 2026" />
  );
}

async function fetchAppointments(): Promise<AppointmentRow[]> {
  // STUB — replace with Supabase query.
  return [
    {
      id: "a1",
      customer_name: "Clara Urgelles",
      customer_initials: "CU",
      store: "Braman Miami",
      type: "Sales",
      vehicle: "2026 BMW X3",
      vehicle_tags: ["🚩"],
      date_label: "Mon, May 11, 2026",
      time_label: "9:30 AM",
      confirmed: "Confirmed",
      status: "Show",
      assigned_to: { name: "Mariangela Perozo", initials: "MP" },
      confirmed_by: { name: "Mariangela Perozo", initials: "MP" },
      created_by: { name: "Mariangela Perozo", initials: "MP" },
    },
    {
      id: "a2",
      customer_name: "Natali Rodriguez",
      customer_initials: "NR",
      store: "Braman Miami",
      type: "Sales",
      vehicle: "2026 MINI Hardtop 4 Door",
      vehicle_tags: ["🍒", "🚩"],
      date_label: "Mon, May 11, 2026",
      time_label: "10:00 AM",
      confirmed: "Pending",
      status: "No Show",
      assigned_to: { name: "Mariana Finol", initials: "MF" },
      confirmed_by: null,
      created_by: { name: "Mariana Finol", initials: "MF" },
    },
    {
      id: "a3",
      customer_name: "Marcel Reinosa",
      customer_initials: "MR",
      store: "Braman Miami",
      type: "Sales",
      vehicle: undefined,
      date_label: "Mon, May 11, 2026",
      time_label: "10:00 AM",
      confirmed: "Confirmed",
      status: "No Show",
      assigned_to: { name: "Guillermo Naranjo", initials: "GN" },
      confirmed_by: { name: "Guillermo Naranjo", initials: "GN" },
      created_by: { name: "Guillermo Naranjo", initials: "GN" },
    },
  ];
}
