import { SalesEngagementHub } from "@/components/pipeline/sales-engagement-hub";
// TODO: import { createServerClient } from "@/lib/supabase/server";

/**
 * /dashboard/pipeline — the AI-powered Sales Engagement Hub.
 *
 * Funnel stages and counts must come from `communications` + `campaigns`
 * + `mail_pieces` aggregated by lifecycle stage. The data shape is fixed
 * by `<SalesEngagementHub>`; only the source of the data is open.
 *
 * Replace `getPipelineSnapshot()` with a real Supabase query when ready.
 */
export default async function PipelinePage() {
  const data = await getPipelineSnapshot();
  return <SalesEngagementHub {...data} />;
}

async function getPipelineSnapshot() {
  // TODO: aggregate from Supabase. Replace this stub.
  return {
    overallEngaged: 62,
    stages: [
      { id: "engaged" as const, label: "Engaged", count: 2802, warnings: 412, hot: 110 },
      { id: "visit" as const, label: "Visit", count: 277, warnings: 109, hot: 18 },
      { id: "proposal" as const, label: "Proposal", count: 1159, warnings: 401, hot: 84 },
      { id: "sold" as const, label: "Sold", count: 63, warnings: 38, hot: 3 },
      { id: "delivered" as const, label: "Delivered", count: 136, customers: 83 },
    ],
    dropoffs: [12, 12, 3, 1],
    channels: [
      { id: "snooze" as const, label: "Snooze", count: 271 },
      { id: "snaps" as const, label: "Snaps", count: 0 },
      { id: "videos" as const, label: "Videos", count: 13 },
      { id: "insite" as const, label: "InSite", count: 4 },
    ],
  };
}
