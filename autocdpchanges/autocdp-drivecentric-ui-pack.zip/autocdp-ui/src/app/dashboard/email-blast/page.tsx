import { EmailBlastTable, type EmailBlastRow } from "@/components/email-blast/email-blast-table";

/**
 * /dashboard/email-blast
 *
 * High-level email campaign log. Each row is an aggregation over
 * `communications` for a single campaign + channel='email'.
 *
 * `email_score` should be supplied by our AI grader — a Sonnet 4.6 call that
 * evaluates the subject + body for spam triggers, personalisation, CTAs.
 * Cache the score on the campaign row to avoid re-grading on every render.
 */
export default async function EmailBlastPage() {
  const rows = await fetchEmailBlasts();
  return <EmailBlastTable rows={rows} />;
}

async function fetchEmailBlasts(): Promise<EmailBlastRow[]> {
  // STUB — replace with Supabase aggregation.
  return [
    {
      id: "eb1",
      store: "Braman Miami",
      status: "Complete",
      subject: "MINI Lease Offers from $369/mo 🚗",
      created_by: { name: "Melissa Fowler", initials: "MF" },
      created_label: "3 days ago",
      email_score: "Good",
      send_date: "05/08/2026 - 04:30 PM",
      sent: 2149,
      opened: 385,
      clicked: 7,
      replied: null,
      issues: 4,
    },
    {
      id: "eb2",
      store: "Braman Miami",
      status: "Complete",
      subject: "BMW Lease Offers from $349/mo 🏎️",
      created_by: { name: "Melissa Fowler", initials: "MF" },
      created_label: "3 days ago",
      email_score: "Good",
      send_date: "05/08/2026 - 04:30 PM",
      sent: 3308,
      opened: 643,
      clicked: 49,
      replied: null,
      issues: 3,
    },
    {
      id: "eb3",
      store: "Braman Miami",
      status: "Complete",
      subject: "Be the First to Drive the New BMW iX3",
      created_by: { name: "Melissa Fowler", initials: "MF" },
      created_label: "3 days ago",
      email_score: "Excellent",
      send_date: "05/08/2026 - 10:00 AM",
      sent: 6275,
      opened: 1173,
      clicked: 26,
      replied: 1,
      issues: 12,
    },
    {
      id: "eb4",
      store: "Braman Miami",
      status: "Complete",
      subject: "Be the First to Drive the New BMW iX3 - Reserve Now",
      created_by: { name: "Melissa Fowler", initials: "MF" },
      created_label: "3 days ago",
      email_score: "Good",
      send_date: "05/08/2026 - 10:00 AM",
      sent: 18,
      opened: 11,
      clicked: null,
      replied: null,
      issues: null,
    },
  ];
}
