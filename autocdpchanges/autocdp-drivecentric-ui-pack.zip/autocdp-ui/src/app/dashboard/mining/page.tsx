import { MiningKPIGrid, type MiningKPI } from "@/components/mining/mining-kpi-grid";

/**
 * /dashboard/mining
 *
 * AI-powered KPI grid surfacing actionable customer segments. Each tile is a
 * saved query — clicking it should drill into a filtered Leads list.
 *
 * Counts must come from real Supabase aggregations. The `shared` flag means
 * "this query is part of the cross-dealership global library" (similar to
 * how `global_learnings` is shared).
 */
export default async function MiningPage() {
  const kpis = await fetchMiningKPIs();
  return (
    <MiningKPIGrid
      storeName="Braman Miami"
      lastUpdated="05/11/26 at 12:26 AM"
      kpis={kpis}
    />
  );
}

async function fetchMiningKPIs(): Promise<MiningKPI[]> {
  // STUB — replace with Supabase aggregations.
  return [
    { id: "1", label: "Lease Ending (3 Months)", count: 280, shared: true, entity: "vehicle" },
    { id: "2", label: "Electric Vehicle Sales 3-5 Years Sold", count: 295, shared: true, entity: "vehicle" },
    { id: "3", label: "BMW Customers Coming out of Contract <18 months", count: 1919, shared: true, entity: "vehicle" },
    { id: "4", label: "MINI All Time Deals", count: 97258, shared: true, entity: "vehicle" },
    { id: "5", label: "True Car 90 Days", count: 741, shared: true, entity: "vehicle" },
    { id: "6", label: "BMW New Car MyOffer Car Now Engaged, Lead, Visit", count: 74, shared: true, entity: "vehicle" },
    { id: "7", label: "BMW New Car Run My Lease", count: 90, shared: true, entity: "vehicle" },
    { id: "8", label: "Buy Now July - Sept 2025", count: 11, shared: true, entity: "vehicle" },
    { id: "9", label: "Next Gen Car Now Buy Now Leads This Month", count: 46, shared: true, entity: "vehicle" },
    { id: "10", label: "Next Gen BYO Leads This Month", count: 29, shared: true, entity: "vehicle" },
    { id: "11", label: "Next Gen BMWUSA Leads This Month", count: 7, shared: true, entity: "vehicle" },
    { id: "12", label: "Next Gen Dealer Website Leads This Month", count: 95, shared: true, entity: "vehicle" },
    { id: "13", label: "Next Gen Dealer Contact Leads This Month", count: 8, shared: true, entity: "vehicle" },
    { id: "14", label: "Next Gen Test Drive Leads This Month", count: 7, shared: true, entity: "vehicle" },
    { id: "15", label: "Next Gen Get A Quote Leads This Month", count: 30, shared: true, entity: "vehicle" },
    { id: "16", label: "Next Gen Check Availability Leads This MOnth", count: 3, shared: true, entity: "vehicle" },
    { id: "17", label: "BMW Email Database Audience", count: 11605, shared: true, entity: "vehicle" },
    { id: "18", label: "MINI Email Database Audience", count: 2625, shared: true, entity: "vehicle" },
    { id: "19", label: "Sold 2022+ Mercedes-Benz G and S", count: 83, shared: true, entity: "vehicle" },
    { id: "20", label: "Sold 2022+ Porsche 911 & Cayenne", count: 146, shared: true, entity: "vehicle" },
    { id: "21", label: "X3 Open New Car Prospects within last 75 Days", count: 362, shared: true, entity: "vehicle" },
    { id: "22", label: "X5 Open New Car Prospects w/in 75 days", count: 293, shared: true, entity: "vehicle" },
    { id: "23", label: "Next Gen KPI Leads - Tag Customers Daily", count: 473, shared: true, entity: "vehicle" },
    { id: "24", label: "Open Deals", count: 5309, entity: "vehicle" },
    { id: "25", label: "Orphans", count: 489360, entity: "customer" },
    { id: "26", label: "Yesterday's Visits", count: 6, entity: "vehicle" },
    { id: "27", label: "Yesterday's Proposals", count: 10, entity: "vehicle" },
    { id: "28", label: "Lease Ending (3 Months)", count: 280, entity: "vehicle" },
    { id: "29", label: "High Interest Rate (9.9+)", count: 2058, entity: "vehicle" },
    { id: "30", label: "Deliveries This Year", count: 2092, entity: "vehicle" },
    { id: "31", label: "Customers Coming out of Contract (<18 Months)", count: 2830, entity: "vehicle" },
    { id: "32", label: "Birthdays This Month", count: 5142, entity: "customer" },
    { id: "33", label: "Wish List Customers", count: 87, entity: "customer" },
  ];
}
