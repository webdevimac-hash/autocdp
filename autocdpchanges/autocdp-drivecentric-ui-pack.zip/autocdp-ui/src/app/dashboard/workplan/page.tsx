import { WorkplanPage, type WorkplanTaskGroup } from "@/components/workplan/workplan-page";

/**
 * /dashboard/workplan
 *
 * The dealer's daily action list. Groups are bucketed by date; each group has
 * a progress bar and a breakdown of how many calls/texts/emails/etc still
 * need to happen. When everything is done we render the celebration state.
 *
 * Source data: aggregate `planned_tasks` (a future table) or compute on the
 * fly from `communications.status='pending'` + scheduled cadence rules in
 * `src/lib/cadence.ts`.
 */
export default async function WorkplanRoute() {
  const groups = await fetchWorkplan();
  const allComplete = groups.every((g) => g.completed === g.total);
  return <WorkplanPage groups={groups} allComplete={allComplete} />;
}

async function fetchWorkplan(): Promise<WorkplanTaskGroup[]> {
  // STUB — replace with real query.
  return [
    {
      id: "today",
      date_label: "MONDAY, MAY 11",
      title: "Completed Tasks",
      completed: 0,
      total: 0,
      counts: { calls: 0, texts: 0, emails: 0, videos: 0, tasks: 0 },
    },
  ];
}
