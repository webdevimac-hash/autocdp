import { ReputationDashboard, type ReputationData } from "@/components/reputation/reputation-dashboard";

/**
 * /dashboard/reputation
 *
 * Aggregates reviews from connected sources (Google, DealerRater, etc.) along
 * with sentiment from our AI grader. Stats are scoped to the active filter
 * range. Distribution is the bar chart that appears next to the average.
 */
export default async function ReputationPage() {
  const data = await fetchReputation();
  return <ReputationDashboard data={data} />;
}

async function fetchReputation(): Promise<ReputationData> {
  // STUB — replace with real source feed once review integrations land.
  return {
    total_reviews: 0,
    comments: 0,
    average_rating: 0,
    distribution: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 },
    sales: { value: "— %", period_label: "Last 30 Days" },
    services: { value: "— %", period_label: "Last 30 Days" },
    non_sold_visits: { value: "— %", period_label: "Last 30 Days" },
    reviews: [],
  };
}
